from ultralytics import YOLO

yolo = YOLO("./yolo11n.pt",task="det"   )

result = yolo(source='F1.jpg')